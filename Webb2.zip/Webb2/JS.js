function pageScroll1() 
{
        window.scrollTo(0,700);
        this.end;
}
function pageScroll2() 
{
        window.scrollTo(0, 1000);
        this.end;
}

function pageScroll3() 
{
        window.scrollTo(0, 1500);
        this.end;
}
function pageScroll4() 
{
        window.scrollTo(0, 0);
        this.end;
}
